package com.example.passcontainer;

import android.app.Application;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.HashMap;

public class changePasswordAndDatabase {
    final String fixedPassword = "xxxxxxxxxxxxxxxx"; //Enter any custom password
    private String databaseName = "genEncryptedPassword";
    String loginPassword;

    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
    public void encryptedPasswordChanger(dbCreatorHandler db, String newLoginPassword) throws Exception {
        String backedUpDatabasePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.passcontainer";
        encryptDecryptPassword encryption = new encryptDecryptPassword();

        File file = new File(backedUpDatabasePath + "/98e79097-6788-463d-8db1-fba27c1a0458.tmp");
        try {
            //Retrieve previous password
            FileReader reader = new FileReader(backedUpDatabasePath + "/98e79097-6788-463d-8db1-fba27c1a0458.tmp");
            char[] data = new char[(int) file.length()];
            reader.read(data);
            reader.close();
            String convertedData = new String(data);
            String[] encryptedData = convertedData.split("--##!!");
            loginPassword = encryption.decryptPassword(fixedPassword, encryptedData[0], encryptedData[1], encryptedData[2]);

            //Get database content
            Cursor cursor = db.execSql("SELECT * FROM passwords");

            //Modify content of database by setting it for login authentication of new change password
            while (cursor.moveToNext()) {
                String websiteName = cursor.getString(0);
                String encryptedPassword = cursor.getString(1);
                String iv = cursor.getString(2);
                String salt = cursor.getString(3);
                String decryptedPassword = encryption.decryptPassword(loginPassword, encryptedPassword, iv, salt);
                HashMap<String, String> keyMap = encryption.encryptPassword(newLoginPassword, decryptedPassword, "default");
                db.deleteWebsiteData(websiteName);
                db.addNewWebsiteData(websiteName, keyMap.get("encrypted"), keyMap.get("iv"), keyMap.get("salt"));
            }

            cursor.close();
            db.close();
        } catch (Exception error) {
            Log.d("ChangePasswordClassDB", error.toString());
        }
    }

}
