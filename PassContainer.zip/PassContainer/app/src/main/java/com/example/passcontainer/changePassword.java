package com.example.passcontainer;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

public class changePassword extends AppCompatActivity {
    final static String mainDatabaseName = "mainPassword";
    final static String encryptedDatabaseName = "genEncryptedPassword";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        changePasswordRequested();
    }

    public void changePasswordRequested() {
        final Button changeInAppPassword = findViewById(R.id.changePasswordConfirm);
        changeInAppPassword.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {

                final TextView password1 = findViewById(R.id.newChangedPassword);
                String newPassword = password1.getText().toString();
                final TextView password2 = findViewById(R.id.recheckChangedPassword);
                String reenteredPassword = password2.getText().toString();

                if (newPassword.equals("") && reenteredPassword.equals("")) {
                    Toast.makeText(changePassword.this, "Both Password box cannot be left empty!", Toast.LENGTH_SHORT).show();
                } else if (newPassword.equals("")) {
                    Toast.makeText(changePassword.this, "New Password box cannot be left empty!", Toast.LENGTH_SHORT).show();
                } else if (reenteredPassword.equals("")) {
                    Toast.makeText(changePassword.this, "Reentered Password box cannot be left empty!", Toast.LENGTH_SHORT).show();

                } else if (newPassword.equals(reenteredPassword)) {
                    if (newPassword.length() > 9) {
                        try {
                            encryptDecryptPassword encryption = new encryptDecryptPassword();
                            dbCreatorHandler mainDb = new dbCreatorHandler(changePassword.this, mainDatabaseName, null, 1);
                            changePasswordAndDatabase changer = new changePasswordAndDatabase();

                            //Delete previous database Table
                            mainDb.clearMainDatabaseTable();

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                                //Change password for encrypted password database
                                dbCreatorHandler encryptedDb = new dbCreatorHandler(changePassword.this, encryptedDatabaseName, null, 1);
                                changer.encryptedPasswordChanger(encryptedDb, newPassword);
                            }

                            HashMap<String, String> keyMap = encryption.encryptPassword(newPassword, null, "custom");
                            mainDb.addNewWebsiteData("mainAppContent", keyMap.get("encrypted"), keyMap.get("iv"), keyMap.get("salt"));

                            //Take backup of current database
                            backup takeBackup = new backup();

                            Path mainDatabasePath = Paths.get(String.valueOf(getDatabasePath(mainDatabaseName)));
                            Path encryptedDatabasePath = Paths.get(String.valueOf(getDatabasePath(encryptedDatabaseName)));

                            takeBackup.createBackupPassword(newPassword, mainDatabasePath);
                            takeBackup.createBackupPassword(newPassword, encryptedDatabasePath);

                            Toast.makeText(changePassword.this, "Password Changed Successfully", Toast.LENGTH_SHORT).show();

                            finish();
                            Intent intent = new Intent(changePassword.this, MainActivity.class);
                            startActivity(intent);
                            overridePendingTransition(0, 0);
                        } catch (Exception error) {
                            Toast.makeText(changePassword.this, "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(changePassword.this, "Please enter password with length greater than 10 characters.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(changePassword.this, "Password entered are not same:-(", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
}