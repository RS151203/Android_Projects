package com.example.passcontainer;

import java.util.Random;

public class passwordGenerator {
    public String passwordGen() {
        StringBuilder password = new StringBuilder((16));
        String toChooseFrom = "abcdefghijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ1234567890!#$%^&*";
        char[] randomCharArray = toChooseFrom.toCharArray();
        for (int i = 0; i < 16; i++) {
            Random random = new Random();
            int index = random.nextInt(toChooseFrom.length());
            password.append(randomCharArray[index]);
        }
        return password.toString();
    }
}
