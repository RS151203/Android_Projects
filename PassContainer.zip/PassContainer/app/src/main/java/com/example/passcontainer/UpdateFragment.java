package com.example.passcontainer;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

public class UpdateFragment extends Fragment {


    private String databaseName = "genEncryptedPassword";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View fragmentView = inflater.inflate(R.layout.fragment_update, container, false);

        Button generatePassword = fragmentView.findViewById(R.id.genPasswordToUpdate);
        generatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView toShowGeneratedPassword = fragmentView.findViewById(R.id.updatePasswordGenResult);
                passwordGenerator genPassword = new passwordGenerator();
                String passwordToStore = genPassword.passwordGen();
                toShowGeneratedPassword.setText(passwordToStore);
            }
        });

        Button addPasswordToDatabase = fragmentView.findViewById(R.id.passwordToUpdate);
        addPasswordToDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity2 mainActivity2 = (MainActivity2) getActivity();
                String decodedLoginPassword = mainActivity2.decodedPassword();

                encryptDecryptPassword passwordEncryption = new encryptDecryptPassword();

                dbCreatorHandler dbCreatorHandler = new dbCreatorHandler(getContext(), databaseName, null, 1);

                TextView websitename = fragmentView.findViewById(R.id.websiteNameToUpdate);
                String websiteName = websitename.getText().toString().trim();

                TextView username = fragmentView.findViewById(R.id.userNameToUpdate);
                String userName = username.getText().toString().trim();

                TextView custompassword = fragmentView.findViewById(R.id.enterPasswordToUpdate);
                String customPassword = custompassword.getText().toString();

                TextView toshowgeneratedpassword = fragmentView.findViewById(R.id.updatePasswordGenResult);
                String toShowGeneratedPassword = toshowgeneratedpassword.getText().toString();

                if (toShowGeneratedPassword.equals("") & customPassword.equals("")) {
                    Toast.makeText(getContext(), "Enter custom password or generate Password", Toast.LENGTH_SHORT).show();
                } else if (customPassword.equals("")) {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        try {
                            HashMap<String, String> keyMap = passwordEncryption.encryptPassword(decodedLoginPassword, toShowGeneratedPassword, "default");
                            dbCreatorHandler.updateWebsiteData(websiteName+userName, keyMap.get("encrypted"), keyMap.get("iv"), keyMap.get("salt"));
                            backup takeBackup = new backup();
                            Path databasePath = Paths.get(String.valueOf(mainActivity2.getDatabasePath(databaseName)));
                            takeBackup.createBackupPassword(decodedLoginPassword, databasePath);
                            custompassword.setText("");
                            toshowgeneratedpassword.setText("");
                            Toast.makeText(getContext(), "Website updated Successfully", Toast.LENGTH_SHORT).show();
                        } catch (Exception error) {
                            Toast.makeText(getContext(), "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else if (toShowGeneratedPassword.equals("")) {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        try {
                            HashMap<String, String> keyMap = passwordEncryption.encryptPassword(decodedLoginPassword, customPassword, "default");
                            dbCreatorHandler.updateWebsiteData(websiteName+userName, keyMap.get("encrypted"), keyMap.get("iv"), keyMap.get("salt"));
                            backup takeBackup = new backup();
                            Path databasePath = Paths.get(String.valueOf(mainActivity2.getDatabasePath(databaseName)));
                            takeBackup.createBackupPassword(decodedLoginPassword, databasePath);
                            custompassword.setText("");
                            toshowgeneratedpassword.setText("");
                            Toast.makeText(getContext(), "Website added Successfully", Toast.LENGTH_SHORT).show();
                        } catch (Exception error) {
                            Toast.makeText(getContext(), "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    toshowgeneratedpassword.setText("");
                    Toast.makeText(getContext(), "Please either enter password or generate password", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return fragmentView;
    }

    @Override
    public void onPause() {
        super.onPause();
        TextView websitename = getView().findViewById(R.id.websiteNameToUpdate);
        websitename.setText("");

        TextView username = getView().findViewById(R.id.userNameToUpdate);
        username.setText("");

        TextView custompassword = getView().findViewById(R.id.enterPasswordToUpdate);
        custompassword.setText("");

        TextView toshowgeneratedpassword = getView().findViewById(R.id.updatePasswordGenResult);
        toshowgeneratedpassword.setText("");
    }
}