package com.example.passcontainer;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    final static String mainDatabaseName = "mainPassword";
    final static String encryptedDatabaseName = "genEncryptedPassword";
    backup takeBackup = new backup();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                File dbFile = MainActivity.this.getDatabasePath(mainDatabaseName);
                Boolean dbExistence = dbFile.exists();
                if (!Environment.isExternalStorageManager()) {
                    Toast.makeText(MainActivity.this, "Please give permission to PassContainer", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                    finishAffinity();
                    finishAndRemoveTask();

                } else {
                    if (dbExistence.equals(Boolean.TRUE)) {
                        setContentView(R.layout.login_screen);
                        loginRequested();

                    } else {
                        setContentView(R.layout.activity_main);
                        signinRequested();
                    }
                }
            }
        } catch (Exception error) {
            Toast.makeText(MainActivity.this, "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
        }
    }

    public void signinRequested() {
        final Button signIn = findViewById(R.id.signIn);
        signIn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {

                final TextView password1 = findViewById(R.id.password);
                String newPassword = password1.getText().toString();
                final TextView password2 = findViewById(R.id.renteredPassword);
                String reenteredPassword = password2.getText().toString();

                if (newPassword.equals("") && reenteredPassword.equals("")) {
                    Toast.makeText(MainActivity.this, "Both Password box cannot be left empty!", Toast.LENGTH_SHORT).show();
                } else if (newPassword.equals("")) {
                    Toast.makeText(MainActivity.this, "New Password box cannot be left empty!", Toast.LENGTH_SHORT).show();
                } else if (reenteredPassword.equals("")) {
                    Toast.makeText(MainActivity.this, "Reentered Password box cannot be left empty!", Toast.LENGTH_SHORT).show();

                } else if (newPassword.equals(reenteredPassword)) {
                    if (newPassword.length() > 9) {
                        encryptDecryptPassword encryption = new encryptDecryptPassword();
                        dbCreatorHandler db = new dbCreatorHandler(MainActivity.this, mainDatabaseName, null, 1);
                        try {
                            HashMap<String, String> keyMap = encryption.encryptPassword(newPassword, null, "custom");
                            db.addNewWebsiteData("mainAppContent", keyMap.get("encrypted"), keyMap.get("iv"), keyMap.get("salt"));

                            Boolean backupExistenceStatus = takeBackup.checkIfBackupExists();
                            if (backupExistenceStatus) {

                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setIcon(android.R.drawable.ic_dialog_alert).setTitle("Backup Found").setMessage("Would you like to restore previous passwords?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dbCreatorHandler encryptedDb = new dbCreatorHandler(MainActivity.this, encryptedDatabaseName, null, 1);
                                        changePasswordAndDatabase changer = new changePasswordAndDatabase();
                                        try {
                                            takeBackup.copyBackupToOriginalLocation();
                                            changer.encryptedPasswordChanger(encryptedDb, newPassword);
                                        } catch (Exception error) {
                                            Toast.makeText(MainActivity.this, "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
                                        }
                                        finish();
                                        startActivity(getIntent());
                                        overridePendingTransition(0, 0);
                                    }
                                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.cancel();
                                        finish();
                                        startActivity(getIntent());
                                        overridePendingTransition(0, 0);
                                    }
                                });
                                AlertDialog alert = builder.create();
                                alert.show();
                            } else {
                                Path databasePath = Paths.get(String.valueOf(getDatabasePath(mainDatabaseName)));
                                takeBackup.createBackupFolder();
                                takeBackup.createBackupPassword(newPassword, databasePath);
                                finish();
                                startActivity(getIntent());
                                overridePendingTransition(0, 0);

                            }


                        } catch (Exception error) {
                            Toast.makeText(MainActivity.this, "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(MainActivity.this, "Please enter password with length greater than 10 characters.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Password entered are not same:-(", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

    public void loginRequested() {
        final Button login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {

                final TextView password = findViewById(R.id.loginPassword);
                String finalPassword = password.getText().toString();
                encryptDecryptPassword encryption = new encryptDecryptPassword();
                dbCreatorHandler db = new dbCreatorHandler(MainActivity.this, mainDatabaseName, null, 1);
                try {
                    ArrayList<String> fetchedData = db.getWebsiteData("mainAppContent");
                    String decryptedPassword = encryption.decryptPassword(finalPassword, fetchedData.get(0), fetchedData.get(1), fetchedData.get(2));
                    Intent passwordGenScreen = new Intent(MainActivity.this, MainActivity2.class);
                    passwordGenScreen.putExtra("password", decryptedPassword);
                    startActivity(passwordGenScreen);

                } catch (Exception error) {
                    Toast.makeText(MainActivity.this, "WRONG PASSWORD HAS BEEN ENTERED:-(", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}