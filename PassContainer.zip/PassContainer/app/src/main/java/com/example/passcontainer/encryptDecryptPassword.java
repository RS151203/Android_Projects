package com.example.passcontainer;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.HashMap;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class encryptDecryptPassword {
    final HashMap<String, String> keys = new HashMap<String, String>();
    String decryptedPassword;

    @RequiresApi(api = Build.VERSION_CODES.O)
    public HashMap<String, String> encryptPassword(String loginPassword, String toStorePassword, String mode) throws Exception {
        if (mode.equals("custom")) {
            //Generate initialization vector for AES Algorithm.

            SecureRandom ivRandom = new SecureRandom();
            byte[] iv = new byte[16];
            ivRandom.nextBytes(iv);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);

            //Creating Salt
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[256];
            random.nextBytes(salt);

            //Creating SecretKeyFactory object
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            //Creating KeySpec object
            KeySpec spec = new PBEKeySpec(loginPassword.toCharArray(), salt, 65536, 256);
            byte[] hash = factory.generateSecret(spec).getEncoded();
            SecretKeySpec finalKey = new SecretKeySpec(hash, "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, finalKey, ivSpec);
            byte[] encryptedPassword = cipher.doFinal(loginPassword.getBytes(StandardCharsets.UTF_8));
            keys.put("encrypted", Base64.getEncoder().encodeToString(encryptedPassword));
            keys.put("iv", Base64.getEncoder().encodeToString(iv));
            keys.put("salt", Base64.getEncoder().encodeToString(salt));

        } else if (mode.equals("default")) {
            //Generate initialization vector for AES Algorithm.

            SecureRandom ivRandom = new SecureRandom();
            byte[] iv = new byte[16];
            ivRandom.nextBytes(iv);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);

            //Creating Salt
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[256];
            random.nextBytes(salt);

            //Creating SecretKeyFactory object
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            //Creating KeySpec object
            KeySpec spec = new PBEKeySpec(loginPassword.toCharArray(), salt, 65536, 256);
            byte[] hash = factory.generateSecret(spec).getEncoded();
            SecretKeySpec finalKey = new SecretKeySpec(hash, "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, finalKey, ivSpec);
            byte[] encryptedPassword = cipher.doFinal(toStorePassword.getBytes(StandardCharsets.UTF_8));
            keys.put("encrypted", Base64.getEncoder().encodeToString(encryptedPassword));
            keys.put("iv", Base64.getEncoder().encodeToString(iv));
            keys.put("salt", Base64.getEncoder().encodeToString(salt));
        }


        return keys;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public String decryptPassword(String password, String encryptedPassword, String iv, String salt) throws Exception {
        IvParameterSpec ivSpec = new IvParameterSpec(Base64.getDecoder().decode(iv));
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

        KeySpec spec = new PBEKeySpec(password.toCharArray(), Base64.getDecoder().decode(salt), 65536, 256);
        byte[] hash = factory.generateSecret(spec).getEncoded();
        SecretKeySpec finalKey = new SecretKeySpec(hash, "AES");

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, finalKey, ivSpec);
        decryptedPassword = new String(cipher.doFinal(Base64.getDecoder().decode(encryptedPassword)));
        return decryptedPassword;
    }
}
