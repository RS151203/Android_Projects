package com.example.passcontainer;


import android.os.Build;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class backup {
    final String fixedPassword = "xxxxxxxxxxxxxxxx"; //Enter any custom password

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createBackupFolder() {

        String backupPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.passcontainer";
        new File(backupPath).mkdirs();

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createBackupPassword(String backupPassword, Path sourcePath) throws Exception {
        try {
            String destinationPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.passcontainer";
            encryptDecryptPassword encrypted = new encryptDecryptPassword();
            File dbfile = new File(destinationPath + "/cache");
            File passwordfile = new File(destinationPath + "/98e79097-6788-463d-8db1-fba27c1a0458.tmp");

            if (dbfile.exists()) {
                dbfile.delete();
            }
            if (passwordfile.exists()) {
                passwordfile.delete();
            }

            Files.copy(sourcePath, Paths.get(destinationPath + "/cache"));
            HashMap<String, String> keyMap = encrypted.encryptPassword(fixedPassword, backupPassword, "default");
            FileWriter writer = new FileWriter(destinationPath + "/98e79097-6788-463d-8db1-fba27c1a0458.tmp");
            writer.write(keyMap.get("encrypted") + "--##!!" + keyMap.get("iv") + "--##!!" + keyMap.get("salt"));
            writer.close();
        } catch (Exception error) {
            Log.d("ChangePasswordClassBack", String.valueOf(error));
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkIfBackupExists() {
        Path backupPath = Paths.get(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.passcontainer");
        File backupDir = new File(backupPath.toString());
        boolean doesBackupExists;
        if (Files.exists(backupPath) && Files.isDirectory(backupPath)) {
            String[] filesArray = backupDir.list();
            List<String> contentsOfBackupFolder = Arrays.asList(filesArray);
            if (contentsOfBackupFolder.contains("cache") && contentsOfBackupFolder.contains("98e79097-6788-463d-8db1-fba27c1a0458.tmp")) {
                doesBackupExists = true;
            } else {
                doesBackupExists = false;
            }
        } else {
            doesBackupExists = false;
        }
        return doesBackupExists;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void copyBackupToOriginalLocation() throws Exception {
        try {
            String dbPath = "/data/user/0/com.example.passcontainer/databases/genEncryptedPassword";
            String backupPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.passcontainer";
            new File(backupPath + "/cache").renameTo(new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.passcontainer/genEncryptedPassword"));
            Files.move(Paths.get(backupPath + "/genEncryptedPassword"), Paths.get(dbPath), StandardCopyOption.REPLACE_EXISTING);

        } catch (IOException error) {
            Log.d("ChangePasswordClassBack", String.valueOf(error));
        }
    }
}
