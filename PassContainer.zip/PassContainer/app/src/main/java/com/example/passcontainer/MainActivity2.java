package com.example.passcontainer;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayoutMediator;


import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity implements TabLayoutMediator.TabConfigurationStrategy {

    private ViewPager2 viewPager2;
    ArrayList<String> functions;

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        viewPager2 = findViewById(R.id.viewpager2);
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        functions = new ArrayList<>();
        functions.add("FETCH");
        functions.add("ADD");
        functions.add("UPDATE");
        functions.add("DELETE");
        setViewPagerAdapter();
        new TabLayoutMediator(tabLayout, viewPager2, this).attach();
        int heightOfScreen = getResources().getDisplayMetrics().heightPixels;
        int heightOfTabLayout;
        int heightOfViewPager;
        int actionBarHeight = 120;
        ViewGroup.LayoutParams params = viewPager2.getLayoutParams();
        if (heightOfScreen <= 1200) {
            heightOfTabLayout = 75;
            heightOfViewPager = (int) (heightOfScreen - heightOfTabLayout - actionBarHeight * 2.25);
        } else if (heightOfScreen > 1200 && heightOfScreen <= 1400) {
            heightOfTabLayout = 100;
            heightOfViewPager = heightOfScreen - heightOfTabLayout - actionBarHeight;
        } else {
            heightOfTabLayout = 125;
            heightOfViewPager = heightOfScreen - heightOfTabLayout - actionBarHeight;
        }
        params.height = heightOfViewPager;
        viewPager2.setLayoutParams(params);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.changeMainDBPassword) {
            Intent takeBackup = new Intent(this, changePassword.class);
            startActivity(takeBackup);
        } else if (item.getItemId() == R.id.searchWebsiteUserName) {
            Intent search = new Intent(this, findUserName.class);
            startActivity(search);
        } else if (item.getItemId() == R.id.contactUs) {
            String siteUrl = "https://liverpudlian-fixtur.000webhostapp.com/PassContainer.html";
            Intent website = new Intent(Intent.ACTION_VIEW);
            website.setData(Uri.parse(siteUrl));
            startActivity(website);
        }
        return super.onOptionsItemSelected(item);
    }

    public void setViewPagerAdapter() {
        ViewPager2Adapter viewPager2Adapter = new ViewPager2Adapter(this);
        ArrayList<Fragment> fragmentArrayList = new ArrayList<>();
        fragmentArrayList.add(new FetchFragment());
        fragmentArrayList.add(new AddFragment());
        fragmentArrayList.add(new UpdateFragment());
        fragmentArrayList.add(new DeleteFragment());

        viewPager2Adapter.setData(fragmentArrayList);
        viewPager2.setAdapter(viewPager2Adapter);
    }

    public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
        tab.setText(functions.get(position));
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    public String decodedPassword() {
        Intent loginScreen = getIntent();
        return loginScreen.getStringExtra("password");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finishAffinity();
        finishAndRemoveTask();
    }
}
