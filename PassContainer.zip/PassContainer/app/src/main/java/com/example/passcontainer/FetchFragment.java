package com.example.passcontainer;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class FetchFragment extends Fragment {
    private String databaseName = "genEncryptedPassword";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_fetch, container, false);

        encryptDecryptPassword passwordEncryption = new encryptDecryptPassword();
        dbCreatorHandler dbCreatorHandler = new dbCreatorHandler(getContext(), databaseName, null, 1);


        Button fetchData = fragmentView.findViewById(R.id.getSitePassword);
        fetchData.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                try {
                    MainActivity2 mainActivity2 = (MainActivity2) getActivity();
                    String decodedLoginPassword = mainActivity2.decodedPassword();
                    TextView sitetofetch = fragmentView.findViewById(R.id.websiteNameToFetch);
                    String siteToFetch = sitetofetch.getText().toString().trim();
                    TextView username = fragmentView.findViewById(R.id.userNameToFetch);
                    String userName = username.getText().toString().trim();

                    if (siteToFetch.equals("")) {
                        Toast.makeText(getContext(), "Please enter site name", Toast.LENGTH_SHORT).show();
                    } else {
                        TextView sitePassword = fragmentView.findViewById(R.id.getSitePasswordResult);
                        ArrayList<String> passwordData = dbCreatorHandler.getWebsiteData(siteToFetch+userName);
                        String decryptedPassword = passwordEncryption.decryptPassword(decodedLoginPassword, passwordData.get(0), passwordData.get(1), passwordData.get(2));
                        sitePassword.setText(decryptedPassword);
                        ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService(getContext().CLIPBOARD_SERVICE);
                        ClipData clipData = ClipData.newPlainText(null, decryptedPassword);
                        clipboardManager.setPrimaryClip(clipData);
                        Toast.makeText(getContext(), "Password copied to clipboard", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception error) {
                    Toast.makeText(getContext(), "Site Name entered doesn't exist!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return fragmentView;
    }

    @Override
    public void onPause() {
        super.onPause();
        TextView sitetofetch = getView().findViewById(R.id.websiteNameToFetch);
        sitetofetch.setText("");

        TextView username = getView().findViewById(R.id.userNameToFetch);
        username.setText("");

        TextView sitePassword = getView().findViewById(R.id.getSitePasswordResult);
        sitePassword.setText("");
    }
}