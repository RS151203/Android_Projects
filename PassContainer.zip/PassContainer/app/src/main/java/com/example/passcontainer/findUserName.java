package com.example.passcontainer;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class findUserName extends AppCompatActivity {
    final static String encryptedDatabaseName = "genEncryptedPassword";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_user_name);
        Button search = findViewById(R.id.searchDb);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    TextView sitename = findViewById(R.id.websiteNameToSearch);
                    String siteName = sitename.getText().toString().trim();
                    dbCreatorHandler db = new dbCreatorHandler(findUserName.this, encryptedDatabaseName, null, 1);
                    Cursor cursor = db.execSql("SELECT websiteName FROM passwords WHERE websiteName LIKE '" + siteName + "%'");
                    StringBuilder foundNames = new StringBuilder();
                    int i = 0;
                    while (cursor.moveToNext()) {
                        i = i + 1;
                        String searchData = cursor.getString(0);
                        String username = searchData.replaceAll(siteName, "");
                        if (!username.equals("")) {
                            foundNames.append(i).append(":-").append(username).append("\n");
                        }
                    }
                    String finalContents = foundNames.toString();
                    TextView result = findViewById(R.id.searchResults);
                    result.setText(finalContents);
                    cursor.close();
                    db.close();
                } catch (Exception error) {
                    Toast.makeText(findUserName.this, "SOME ERROR HAS OCCURED", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onPause() {
        super.onPause();
        TextView sitename = findViewById(R.id.websiteNameToSearch);
        TextView result = findViewById(R.id.searchResults);
        sitename.setText("");
        result.setText("");
    }
}