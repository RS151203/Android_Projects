package com.example.passcontainer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;

public class dbCreatorHandler extends SQLiteOpenHelper {
    String dbName;
    public dbCreatorHandler(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        dbName=name;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE passwords (websiteName TEXT PRIMARY KEY,encryptedPassword TEXT,iv TEXT,salt TEXT)";
        sqLiteDatabase.execSQL(query);
    }

    public void addNewWebsiteData(String websiteName, String encryptedPassword, String iv, String salt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("websiteName", websiteName);
        values.put("encryptedPassword", encryptedPassword);
        values.put("iv", iv);
        values.put("salt", salt);
        db.insert("passwords", null, values);
        db.close();
    }

    public ArrayList<String> getWebsiteData(String siteName) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorWebsite = db.rawQuery("SELECT * FROM passwords WHERE websiteName = '" + siteName + "'", null);
        cursorWebsite.moveToFirst();
        ArrayList<String> dataContainer = new ArrayList<String>();
        dataContainer.add(cursorWebsite.getString(1));
        dataContainer.add(cursorWebsite.getString(2));
        dataContainer.add(cursorWebsite.getString(3));
        cursorWebsite.close();
        db.close();
        return dataContainer;
    }

    public void deleteWebsiteData(String siteName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("passwords", "websiteName=?", new String[]{siteName});
        db.close();
    }

    public void updateWebsiteData(String siteName, String encryptedPassword, String iv, String salt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("websiteName", siteName);
        values.put("encryptedPassword", encryptedPassword);
        values.put("iv", iv);
        values.put("salt", salt);
        db.update("passwords", values, "websiteName=?", new String[]{siteName});
        db.close();
    }

    public void clearMainDatabaseTable() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM passwords");
    }

    public Cursor execSql(String sql){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery(sql,null);
        return cursor;
    }

    public String dbName(){
        return dbName;
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }


}
