package com.example.passcontainer;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.Path;
import java.nio.file.Paths;

public class DeleteFragment extends Fragment {
    private final String databaseName = "genEncryptedPassword";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_delete, container, false);

        dbCreatorHandler dbCreatorHandler = new dbCreatorHandler(getContext(), databaseName, null, 1);


        Button deleteData = fragmentView.findViewById(R.id.deletePassword);
        deleteData.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                try {
                    MainActivity2 mainActivity2 = (MainActivity2) getActivity();
                    String decodedLoginPassword = mainActivity2.decodedPassword();
                    TextView sitetodelete = fragmentView.findViewById(R.id.websiteNameToDelete);
                    String siteToDelete = sitetodelete.getText().toString().trim();
                    TextView username = fragmentView.findViewById(R.id.userNameToDelete);
                    String userName = username.getText().toString().trim();

                    if (siteToDelete.equals("")) {
                        Toast.makeText(getContext(), "Enter site name", Toast.LENGTH_SHORT).show();
                    } else {
                        dbCreatorHandler.deleteWebsiteData(siteToDelete + userName);
                        backup takeBackup = new backup();
                        Path databasePath = Paths.get(String.valueOf(mainActivity2.getDatabasePath(databaseName)));
                        takeBackup.createBackupPassword(decodedLoginPassword, databasePath);
                        Toast.makeText(getContext(), "Data deleted Successfully", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception error) {
                    Toast.makeText(getContext(), "ERROR HAS OCCURRED!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return fragmentView;
    }

    @Override
    public void onPause() {
        super.onPause();
        TextView sitetodelete = getView().findViewById(R.id.websiteNameToDelete);
        sitetodelete.setText("");
        TextView username = getView().findViewById(R.id.userNameToDelete);
        username.setText("");
    }
}